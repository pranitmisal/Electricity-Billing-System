package ElectricityBillingSystem;

import java.util.Scanner;

class Customer {
    private String name;
    private int unitsConsumed;

    public Customer(String name, int unitsConsumed) {
        this.name = name;
        this.unitsConsumed = unitsConsumed;
    }

    public double calculateBill() {
        double totalBill = 0;
        if (unitsConsumed <= 100) {
            totalBill = unitsConsumed * 1.20;
        } else if (unitsConsumed <= 300) {
            totalBill = 100 * 1.20 + (unitsConsumed - 100) * 2;
        } else {
            totalBill = 100 * 1.20 + 200 * 2 + (unitsConsumed - 300) * 3;
        }
        return totalBill;
    }

    public String getName() {
        return name;
    }

    public int getUnitsConsumed() {
        return unitsConsumed;
    }
}

public class ElectricityBillingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();

        System.out.print("Enter units consumed: ");
        int unitsConsumed = scanner.nextInt();

        Customer customer = new Customer(name, unitsConsumed);
        double billAmount = customer.calculateBill();

        System.out.println("Customer Name: " + customer.getName());
        System.out.println("Units Consumed: " + customer.getUnitsConsumed());
        System.out.println("Bill Amount: ₹" + billAmount);

        // Share data with local electricity officer
        System.out.println("Data shared with local electricity officer.");

        scanner.close();
    }
}
